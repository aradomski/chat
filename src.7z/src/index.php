<?php header("Refresh: 0; URL=login.html");?> ?>
