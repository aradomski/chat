<div class="footer">© Adam Radomski</div>
